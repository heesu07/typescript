export function add(a, b) {
  return a + b;
}

export const number = 10;
export function print() {
  console.log('print');
}
