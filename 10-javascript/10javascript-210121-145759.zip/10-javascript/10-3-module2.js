import * as calculator from './10-3-module1.js';
console.log(calculator.add(1, 2));
calculator.print();
calculator.number;
